#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <stdbool.h>

#ifdef _WIN32
    #ifdef BUILD_DLL
        #define DLL_EXPORT __declspec(dllexport)
    #else
        #define DLL_EXPORT __declspec(dllimport)
    #endif
#else
    #define DLL_EXPORT
#endif

typedef struct {
    char **strings;
    int count;
} StringDatabase;

DLL_EXPORT void sort_strings(StringDatabase *db);
DLL_EXPORT void remove_duplicates(StringDatabase *db);
DLL_EXPORT void remove_invalid_lengths(StringDatabase *db);
DLL_EXPORT void save_strings(const char *filename, StringDatabase *db);
DLL_EXPORT StringDatabase* load_strings(const char *filename);
DLL_EXPORT int search_string(StringDatabase *db, const char *query);
DLL_EXPORT void free_database(StringDatabase *db);

#endif
