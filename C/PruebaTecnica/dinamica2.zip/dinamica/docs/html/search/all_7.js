var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['remove_5fduplicates_1',['remove_duplicates',['../programa_8c.html#a027ee74c432b94ca8935b5c5de964f3c',1,'remove_duplicates(StringDatabase *db):&#160;programa.c'],['../string__utils_8c.html#a027ee74c432b94ca8935b5c5de964f3c',1,'remove_duplicates(StringDatabase *db):&#160;string_utils.c'],['../string__utils_8h.html#a502df737164b73c70b415918b2a3b4dc',1,'remove_duplicates(StringDatabase *db):&#160;programa.c']]],
  ['remove_5finvalid_5flengths_2',['remove_invalid_lengths',['../programa_8c.html#a4fa99b0b05cd8ac04d1a4ac02549eda1',1,'remove_invalid_lengths(StringDatabase *db):&#160;programa.c'],['../string__utils_8c.html#a4fa99b0b05cd8ac04d1a4ac02549eda1',1,'remove_invalid_lengths(StringDatabase *db):&#160;string_utils.c'],['../string__utils_8h.html#aae44b5af2578ddadcf85112064ebc819',1,'remove_invalid_lengths(StringDatabase *db):&#160;programa.c']]]
];
