var searchData=
[
  ['load_5fstrings_0',['load_strings',['../programa_8c.html#a9610f4d9a173f5413c5b4d5d7a5cfa6f',1,'load_strings(const char *filename):&#160;programa.c'],['../string__utils_8c.html#a9610f4d9a173f5413c5b4d5d7a5cfa6f',1,'load_strings(const char *filename):&#160;string_utils.c'],['../string__utils_8h.html#ab24794417bcc8f527c1c45b568190066',1,'load_strings(const char *filename):&#160;programa.c']]]
];
