var searchData=
[
  ['save_5fstrings_0',['save_strings',['../programa_8c.html#a6f8a322baeec14ba7fd75ca87d524f6b',1,'save_strings(const char *filename, StringDatabase *db):&#160;programa.c'],['../string__utils_8c.html#a6f8a322baeec14ba7fd75ca87d524f6b',1,'save_strings(const char *filename, StringDatabase *db):&#160;string_utils.c'],['../string__utils_8h.html#a51123834e8ba329b58cc71a0d5162853',1,'save_strings(const char *filename, StringDatabase *db):&#160;programa.c']]],
  ['search_5fstring_1',['search_string',['../programa_8c.html#a4247700a068567dee33c02f1add5de11',1,'search_string(StringDatabase *db, const char *query):&#160;programa.c'],['../string__utils_8c.html#a4247700a068567dee33c02f1add5de11',1,'search_string(StringDatabase *db, const char *query):&#160;string_utils.c'],['../string__utils_8h.html#a78f51b4eed4f3e167e3f1d7fc1256640',1,'search_string(StringDatabase *db, const char *query):&#160;programa.c']]],
  ['sort_5fstrings_2',['sort_strings',['../programa_8c.html#a8934cb124dc46e14129c4d216f9a4a1f',1,'sort_strings(StringDatabase *db):&#160;programa.c'],['../string__utils_8c.html#a8934cb124dc46e14129c4d216f9a4a1f',1,'sort_strings(StringDatabase *db):&#160;string_utils.c'],['../string__utils_8h.html#a02735ecfe03dc54978a598302a896f48',1,'sort_strings(StringDatabase *db):&#160;programa.c']]],
  ['string_5futils_2ec_3',['string_utils.c',['../string__utils_8c.html',1,'']]],
  ['string_5futils_2eh_4',['string_utils.h',['../string__utils_8h.html',1,'']]],
  ['stringdatabase_5',['StringDatabase',['../struct_string_database.html',1,'']]],
  ['strings_6',['strings',['../struct_string_database.html#ae62f890154228972458d13f8b4dd0f11',1,'StringDatabase']]],
  ['swap_5fstrings_7',['swap_strings',['../programa_8c.html#a6928840aecbf1fdb0e76a813ee1c9f83',1,'swap_strings(char **a, char **b):&#160;programa.c'],['../string__utils_8c.html#a6928840aecbf1fdb0e76a813ee1c9f83',1,'swap_strings(char **a, char **b):&#160;string_utils.c']]]
];
