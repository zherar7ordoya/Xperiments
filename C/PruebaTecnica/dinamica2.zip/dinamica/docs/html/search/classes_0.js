var searchData=
[
  ['stringdatabase_0',['StringDatabase',['../struct_string_database.html',1,'']]]
];
