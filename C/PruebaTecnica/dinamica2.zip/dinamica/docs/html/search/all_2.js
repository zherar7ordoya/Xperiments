var searchData=
[
  ['free_5fdatabase_0',['free_database',['../programa_8c.html#aff53df3f1cc5377fd54579ea05853909',1,'free_database(StringDatabase *db):&#160;programa.c'],['../string__utils_8c.html#aff53df3f1cc5377fd54579ea05853909',1,'free_database(StringDatabase *db):&#160;string_utils.c'],['../string__utils_8h.html#a0565794f158b286196448824581aa0fc',1,'free_database(StringDatabase *db):&#160;programa.c']]]
];
