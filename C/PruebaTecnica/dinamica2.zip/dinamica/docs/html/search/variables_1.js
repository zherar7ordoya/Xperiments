var searchData=
[
  ['strings_0',['strings',['../struct_string_database.html#ae62f890154228972458d13f8b4dd0f11',1,'StringDatabase']]]
];
